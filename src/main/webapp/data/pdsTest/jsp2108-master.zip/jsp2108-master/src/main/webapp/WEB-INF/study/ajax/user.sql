desc user;

select * from user order by idx desc;
